import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-flight-card',
  templateUrl: './search-flight-card.component.html',
  styleUrls: ['./search-flight-card.component.css']
})
export class SearchFlightCardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
