export class FlightID{

    travelDate: any;
    flightNumber:string;

    constructor(travelDate:any,flightNumber:string){
        this.travelDate=travelDate;
        this.flightNumber=flightNumber;

    }
}