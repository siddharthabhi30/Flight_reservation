package com.lti.service;

import com.lti.model.PassengerDetails;

public interface PassengerDetailsService {
	public PassengerDetails findPassengerDetailsById(String bookingId);

}
